The default gradebook interface that teachers will use.

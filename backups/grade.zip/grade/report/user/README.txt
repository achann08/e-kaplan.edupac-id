The default gradebook interface for students, showing just the user's own grades.

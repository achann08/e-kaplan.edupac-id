# moodle-gradebook_calc

![Build Status](https://travis-ci.org/danitome24/moodle-local_gradebook.svg?branch=master)
[![Coverage Status](https://coveralls.io/repos/github/danitome24/moodle-local_gradebook/badge.svg?branch=master)](https://coveralls.io/github/danitome24/moodle-local_gradebook?branch=master)

**This plugin is being developed and NOT able to use in production sites**

## Introduction
This moodle plugin has the goal of improve usability when setting grades
in Moodle. Moodle API provides an input where you can write your math
expressions and that is difficult to some teachers. Therefore we are developing
this plugin in order to make easier this process using a web interface.


## Authors

Jordi Pujol Ahulló <jpahullo@gmail.com> (Project director)

Daniel Tomé Fernández <danieltomefer@gmail.com> (Developer)

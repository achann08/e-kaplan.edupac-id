ogv.js 1.8.4
--------------
https://github.com/brion/ogv.js

Instructions to import ogv.js library into Moodle:

1. Download the latest release from https://github.com/brion/ogv.js/releases
   (do not choose "Source code")
2. copy 'ogv-es2017.js' into 'amd/src/local/ogv/ogv.js'.
3. copy all the wasm and js files into 'ogvjs/' folder.

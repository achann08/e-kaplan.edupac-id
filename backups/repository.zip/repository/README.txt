Repository API
==============

This directory contains all the interfaces and plugins for access to repositories.

   Specs:  https://moodledev.io/docs/apis/plugintypes/repository
   Track:  http://tracker.moodle.org/browse/MDL-13766
